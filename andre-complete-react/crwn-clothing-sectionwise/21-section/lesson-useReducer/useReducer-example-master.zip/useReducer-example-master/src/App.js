import React from 'react';

import UseReducerExample from './components/use-reducer-example/use-reducer-example.component';

import './App.css';

const App = props => {
  return (
    <div className='App'>
      <UseReducerExample />
    </div>
  );
};

export default App;
