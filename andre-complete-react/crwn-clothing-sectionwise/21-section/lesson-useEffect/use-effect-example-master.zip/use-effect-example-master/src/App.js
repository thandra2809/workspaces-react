import React from 'react';

import UseEffectExample from './components/use-effect-example/use-effect-example.component';

import './App.css';

const App = props => {
  return <UseEffectExample />;
};

export default App;
