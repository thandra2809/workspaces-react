import React from 'react';

import UseStateExample from './components/use-state-example/use-state-example.component';

import './App.css';

const App = props => {
  return <UseStateExample />;
};

export default App;
